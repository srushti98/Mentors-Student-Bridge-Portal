create trigger t1
  after INSERT
  on order_det
  for each row
  BEGIN IF NEW.oid IN (SELECT o_id from customer) THEN  UPDATE customer c, catalog ca SET c.total = c.total + NEW.qt * ca.cost WHERE NEW.pid=ca.pid; END IF;  END;

