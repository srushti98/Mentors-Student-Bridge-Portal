create procedure update_instudentactivity(IN vactivity_id varchar(5), IN mentor_id varchar(11))
  begin
    declare flag int default 0;
    declare stud_id char(11);
    declare c1 cursor for select stud_mis_id from studentmentorrel where emp_id=mentor_id and changeflag=0;
    declare continue handler for not found set flag=1;
    open c1;
    stud_loop: loop
      fetch c1 into stud_id;
      if flag then
        leave stud_loop;
      end if;
      insert into student_activity_list values(stud_id,vactivity_id,0,null);
    end loop stud_loop;
    close c1;
  end;

