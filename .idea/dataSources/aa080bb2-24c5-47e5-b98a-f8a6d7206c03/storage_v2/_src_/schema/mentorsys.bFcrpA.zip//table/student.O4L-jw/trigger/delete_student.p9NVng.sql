create trigger delete_student
  before DELETE
  on student
  for each row
  begin
    delete from Student_parent_details where stud_mis_id=old.stud_mis_id;
    delete from StudentAcademicDetails where stud_mis_id=old.stud_mis_id;
    delete from StudentExtraDetails where stud_mis_id=old.stud_mis_id;
    delete from student_activity_list where stud_mis_id=old.stud_mis_id;
    delete from studentmentorrel where stud_mis_id=old.stud_mis_id;
end;

