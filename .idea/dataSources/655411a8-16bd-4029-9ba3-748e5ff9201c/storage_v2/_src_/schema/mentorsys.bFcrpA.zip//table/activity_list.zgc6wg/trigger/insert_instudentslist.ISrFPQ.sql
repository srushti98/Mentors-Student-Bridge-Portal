create trigger insert_instudentslist
  after INSERT
  on activity_list
  for each row
  begin
    call update_instudentactivity(new.activity_id,new.mentor_id);
  end;

