create trigger insert_studentdetails
  after INSERT
  on student
  for each row
  begin
    insert into Student_parent_details(stud_mis_id) values(new.stud_mis_id);
    insert into StudentAcademicDetails(stud_mis_id) values(new.stud_mis_id);
    insert into StudentExtraDetails(stud_mis_id) values(new.stud_mis_id);
  end;

